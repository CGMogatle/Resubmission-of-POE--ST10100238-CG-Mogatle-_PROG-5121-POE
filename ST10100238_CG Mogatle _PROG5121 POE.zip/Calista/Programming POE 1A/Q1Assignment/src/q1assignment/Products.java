package q1assignment;
import java.util.Scanner;
public class Products {

    //GLOBAL VARIABLE DECLARATION
    public int SIZE = 1;
    public int numOFtasks = 0;
    private String taskID[] = new String[SIZE];
    private String name1[] = new String[SIZE];
    private String category1[] = new String[SIZE];
    private String duration[] = new String[SIZE];
    private String DEVELOPER[] = new String[SIZE];
    private double PRICETAG[] = new double[SIZE];
    private int stock_levels1[] =  new int[SIZE];
    
   
    private static final Scanner input = new Scanner(System.in);    
    public static String name;
    public static String category;
    public static String warranty;
    public static String supplier;
    public static double price;
    public static int stock_levels;
    public static String code;
    public static Products taskses = new Products();
    public Products(){
    }
    public void SaveProduct(String MODIFIER, String LOCAL, String OBJECT, String PARAMETER, String SWITCH, double ELSE, int DEFAULT)
    //adds a product to the array
    {
        if(numOFtasks== SIZE)
        {reSize();}
        System.out.println("NUMBER OF TASKS BEFORE:" + numOFtasks);
        taskID[numOFtasks] = MODIFIER;
        name1[numOFtasks] = LOCAL;
        category1[numOFtasks] = OBJECT;
        duration[numOFtasks] = PARAMETER;
       DEVELOPER[numOFtasks] = SWITCH;
        PRICETAG[numOFtasks] = ELSE;
        stock_levels1[numOFtasks] = DEFAULT;
        numOFtasks++;
        System.out.println("NUMBER OF TASKS AFTER:" + numOFtasks);
    }
        public void reSize()
            //resize arrays to store more items
        {
        //code array
        String[] ptr = new String[SIZE+1];
        System.arraycopy(taskID, 0, ptr, 0, SIZE);
        for(int  k=0 ; k< SIZE; k++){taskID[k] = null;}SIZE = SIZE +1; taskID = ptr;

        //name array
        ptr = new String[SIZE];
        System.arraycopy(name1, 0, ptr, 0, SIZE-1);
        for(int  k=0 ; k< SIZE-1; k++){ name1[k] = null;} name1 = ptr;

        
        //category array
        ptr = new String[SIZE];
        System.arraycopy(category1, 0, ptr, 0, SIZE-1);
        for(int  k=0 ; k< SIZE-1; k++){category1[k] = null;}category1 = ptr;

        //warranty array
        ptr = new String[SIZE];
        System.arraycopy(duration, 0, ptr, 0, SIZE-1);
        for(int  k=0 ; k< SIZE-1; k++){duration[k] = null;}duration = ptr;

        //supplier array
        ptr = new String[SIZE];
        System.arraycopy(DEVELOPER, 0, ptr, 0, SIZE-1);
        for(int  k=0 ; k< SIZE-1; k++){DEVELOPER[k] = null;}DEVELOPER = ptr;
        
        //price array
        double[]  ptr1 = new double[SIZE];
        System.arraycopy(PRICETAG, 0, ptr1, 0, SIZE-1);PRICETAG = new double[SIZE];PRICETAG = ptr1; 

        //stock_levels array
        int ptr2[] = new int[SIZE];
        System.arraycopy(stock_levels1, 0, ptr2, 0, SIZE-1);
        stock_levels1 =  new int[SIZE];stock_levels1 = ptr2;
    }

    public int getTaskID(String c) {
        if (numOFtasks == 0)
        {return Integer.MAX_VALUE;
        }for(int k=0; k<SIZE; k++)
        {if(taskID[k].equals(c)){return k;}
        }return Integer.MAX_VALUE;}

    
    //GETTERS AND SETTERS
    public String getCode(int keisha)
    {
        return taskID[keisha];
    }
    public void setCode(String code,int keisha) {
        this.taskID[keisha] = code;}

    public String getName(int keisha) {
    return name1[keisha];}

    public void setName(String name, int keisha) {
        this.name1[keisha] = name;}

    public String getCategory(int keisha) {
        return category1[keisha];}

    public void setCategory(String category,int keisha) {
        this.category1[keisha] = category;}

    public String getWarranty(int keisha) {
        return duration[keisha];}

    public void setWarranty(String warranty,int keisha) {
        this.duration[keisha] = warranty;}

    public String getSupplier(int keisha) {
        return DEVELOPER[keisha];}

    public void setSupplier(String supplier,int keisha) {
        this.DEVELOPER[keisha] = supplier;}

    public double getPrice(int keisha) {
        return PRICETAG[keisha];}

    public void setPrice(double price,int keisha) {
        this.PRICETAG[keisha] = price;}

    public int getStock_levels(int keisha){
        return stock_levels1[keisha];}

    public void setStock_levels(int stock_levels,int keisha) {
        this.stock_levels1[keisha] = stock_levels;}
    
    public void prompt()
    //Asks the user if he/she wants to continue or not
    {
        String launchMenuOrTerminateProgram;
        System.out.print(
        "(1) LAUNCH AND LOGIN"
        + "\n(2) EXIT APPLICATION\n ");
        launchMenuOrTerminateProgram = input.nextLine();
        programIn(launchMenuOrTerminateProgram);
    }
    
    public void programIn(String c){//is used by prompt
        String menuChoice;
        if(c.equals("1"))
        {DisplayMenu();
        menuChoice = input.nextLine();
        actionOnMenuChoice(menuChoice);
        }
        else
        {ExitApplication();}}
    public void DisplayMenu() //Displays the menu
    {System.out.println
        ("PLEASE SELECT OPTION FROM THR FOLLOWING LIST\n"
        + "\n1) Capture new TASK"
        + "\n2) Search new TASK"
        + "\n3) Update a TASK DETAILS"
        + "\n4) Delete a TASK ADDED"
        + "\n5) Print Out Report"
        + "\n6) Exit Application");
    }

    public void actionOnMenuChoice (String THABANG){       
       switch (THABANG) {
            case "1":   CaptureProduct();
                        break;
            case "2":   SearchForProduct();
                        break;
            case "3":   UpdateProduct();
                        break;
            case "4":   DeleteProduct();
                        break;
            case "5":   PrintReport();
                        break;
            case "6":   ExitApplication();
                        break;   
            default :
                        System.out.println("404 ERROR!!!!!!!!!!!!!!!!!!!!!!!!!\n");
                        programIn("1");
                        break;
        }
    }    
    public void CaptureProduct() 
    {
        //varibles
        String K,description;
        System.out.println("CAPTURE A NEW PRODUCT\n"
        + "******************************************************\n");
       
        System.out.print("Enter TASK ID: ");
        K = input.nextLine();
        System.out.print("Enter TASK Name: ");
        description = input.nextLine();
        System.out.println();
        selectTASKSTATUS();       
        selectWarranty();
        
        System.out.print("Enter TASK DURATION (HOURS):    ");
        price = input.nextDouble();
        System.out.print("Enter TASK NUMBER:  ");
        stock_levels = input.nextInt();
        input.nextLine();
        System.out.print("Enter DEVELOPER DETAILS:  ");
        supplier = input.nextLine();

        taskses.SaveProduct(K,description,category,warranty,supplier, price,stock_levels);
        numOFtasks++;
        System.out.print("\nTASK DETAILS SAVED SUCCESSFULLY!!! \n");
        prompt();

    }

    public void selectWarranty() {
        System.out.println("\nSELECT THE TASK DURATION YOU WANT: "
         + "\n(1)       1 YEAR \n(ANY KEY)  +2 YEARS.");
        String selection = input.next();
        if (selection.equalsIgnoreCase("1")) {
            warranty = "1 YEAR";
        }else {
            warranty = "+2 YEARS";}
    }
    public String changeWarranty() {
        System.out.println("\nSELECT THE TASK DURATION YOU WANT: "
         + "\n(1)1 YEAR \n(ANY KEY)+2 YEARS.");
        String selection = input.next();
        if (selection.equalsIgnoreCase("1")) {
            return "1 YEAR";
        }else {
            return "2 YEARS";     
        }
    }    public void selectTASKSTATUS(){
        System.out.println("SELECT TASK STATUS: ");
         System.out.println("1)TO DO"
                       + "\n2)DONE"
                        + "\n3)DOING");
        System.out.println();
         String choiceOFselection = input.nextLine();
         //making use of switch statements
        switch (choiceOFselection) {
            case "1":
                category = "TO DO";
                break;
            case "2":
                category = "DONE";
                break;
            case "3":
                category = "DOING";
                break;   
            //should user insert an invalid option   
            default:
            System.out.println("\n404 Error!!!!!!!!!!!!!!!!!!! INVALID SELECTION");
            selectTASKSTATUS();
            break;
        }   
    }
    public void SearchForProduct () {
        System.out.print("Enter TASK ID to search: ");
        String codeToSearch = input.nextLine();
        System.out.println("*****************************************\n");
        int id = taskses.getTaskID(codeToSearch);
        System.out.println("TASK SEARCH RESULTS\n");
        System.out.println("*******************************\n");             
                if( id== Integer.MAX_VALUE)
                {
                    System.out.println("The product cannot be located. Invalid Product");
                    prompt();
                }
                else{ System.out.println(
                     "PRODUCT CODE: "           + taskses.getCode(id)
                    + "\nTASK Name: "           + taskses.getName(id)
                    + "\nTASK STATUS: "         + taskses.getCategory(id)
                    + "\nTASK DURATION: "       + taskses.getWarranty(id)
                    + "\nTASK VALUE:   "        + taskses.getPrice(id)
                    + "\nDEVELOPER NAME: "        + taskses.getSupplier(id)
                    + "\nTASK LEVEL: "          + taskses.getStock_levels(id));
                    }prompt();
    }
    public void UpdateProduct()
    {
        System.out.print("ENTER TASK ID TO UPDATE: ");
        String codeToSearch = input.nextLine();
        double newPrice ;
        int newStockLevel; 
        int id = taskses.getTaskID(codeToSearch);
        String yesOrNo,yesOrNo1,yesOrNo2;
        if(id == Integer.MAX_VALUE)
        {
            System.out.println("TASK ID NOT FOUND!!!!!!!!!!!!!!!!!!!!!!!!!");
            prompt();
        }
        else
        {
            System.out.print("UPDATE TASK DURATION?(y/n):");
            yesOrNo = input.next();
      
            if(yesOrNo.equals("y"))
            {
                System.out.println("ENTER NEW DURATION: " + taskses.getName(id) + "\n");
               taskses.setWarranty(changeWarranty(),id);
            }
            System.out.println("UPDATE TASK PRICE?(y/n):");
            yesOrNo1 = input.next();
            
            if(yesOrNo1.equals("y"))
            {
                System.out.print("ENTER PRICE FOR:" + taskses.getName(id) +" : ");
                newPrice = input.nextInt();
              taskses.setPrice(newPrice,id);
            }

            System.out.println("UPDATE TASK LEVEL?(y/n):");
            yesOrNo2 = input.next();if(yesOrNo2.equals("y"))
            {
                System.out.println("ENTER NEW TASK LEVEL" + taskses.getName(id) + " ");
                newStockLevel = input.nextInt();
               taskses.setStock_levels(newStockLevel,id);
            }

            System.out.println("TASK DETAILS UPDATED SUCCESSFULLY!!!");
            input.nextLine();
            prompt();
        }
    }
    public void DeleteProduct () {
        System.out.print("ENTER TASK ID FOR DELETION!!!!!!!!!!!!!!!!!!!!: ");
        String ccode = input.nextLine();
        int id  =taskses.getTaskID(ccode);

        if(numOFtasks ==1)
        {numOFtasks = 0;}
        if(id != Integer.MAX_VALUE)
        {for(int k=id; k<numOFtasks-1; k++)
            {
               taskID[k] = taskID[k+1];
               name1[k] = name1[k+1];
               category1[k] = category1[k+1];
               duration[k] = duration[k+1];
               DEVELOPER[k] = DEVELOPER[k+1];
               PRICETAG[k] = PRICETAG[k+1];
               stock_levels1[k] = stock_levels1[k+1];}
            if(numOFtasks >0)
            numOFtasks--;}
        else{
        System.out.println("404 ERORR!!!!!!!!!! \nTASK CAN'T BE LOCATED!!!!!!!!!!!!!!!");
        prompt();}
        System.out.println("TASK DELETED successfully!!!");
        prompt();}
        public void PrintReport () {
        double totalAmount  =0.0;
        System.out.println("TASK REPORT");
        System.out.println("*********************************************************");       
        if(numOFtasks == 0 )
        {System.out.println("NO TASK IN AVAILABLE");}
        for(int k=0; k<numOFtasks;k++)
        {
            System.out.println("TASK DETAILS " + (k+1));
            System.out.println("*****************************************************");
            System.out.println("TASK ID:                       " + taskses.taskID[k] +"\n"
            + "TASK NAME:                     "+ taskses.name1[k] + "\n"
            + "TASK STATUS (1-3):             "+ taskses.category1[k] + "\n"
            + "TASK DURATION:                 "+ taskses.duration[k] + "\n" 
            + "TASK PRICE:                    " + taskses.PRICETAG[k] + "\n"
            + "TASK LEVEL:                    " + taskses.stock_levels1[k] + "\n"
            + "DEVELOPER NAME :               " + taskses.DEVELOPER[k] + "\n");
            System.out.println("****************************************************");}
        for(int l=0; l<numOFtasks; l++)
        {totalAmount += taskses.PRICETAG[l];
        }
        System.out.println("TOTAL TASK COUNT : " + numOFtasks);
        System.out.println("TOTAL TASK VALUE:  " + totalAmount);
        if(numOFtasks== 0 )
        {System.out.println("AVERAGE TASK VALUE: " + 0);
        }else System.out.println("AVERAGE TASK VALUE: " 
        + (totalAmount/numOFtasks));    
    }
    public void ExitApplication() {
        System.exit(0);
    }
}
