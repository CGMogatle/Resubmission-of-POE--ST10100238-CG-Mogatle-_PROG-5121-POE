package q1assignment;
import java.util.Scanner;

public class Q1Assignment {
public static Scanner input = new Scanner(System.in);  
public static Products productss = new Products();
public static void main(String[] args){
System.out.println("\n**************************************\nWELCOME TO EASYKANBAN\n****************************************");
productss.prompt();
  }    
}
